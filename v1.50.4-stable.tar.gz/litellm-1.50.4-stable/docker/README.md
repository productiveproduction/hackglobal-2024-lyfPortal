# LiteLLM Docker 

This is a minimal Docker Compose setup for self-hosting LiteLLM.