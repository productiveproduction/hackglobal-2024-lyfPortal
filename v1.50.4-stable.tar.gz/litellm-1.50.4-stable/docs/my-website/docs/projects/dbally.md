Efficient, consistent and secure library for querying structured data with natural language. Query any database with over 100 LLMs ❤️ 🚅.

🔗 [GitHub](https://github.com/deepsense-ai/db-ally)
