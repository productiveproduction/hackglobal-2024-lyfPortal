Prompt2Model - Generate Deployable Models from Instructions

Github: https://github.com/neulab/prompt2model

Prompt2Model is a system that takes a natural language task description (like the prompts used for LLMs such as ChatGPT) to train a small special-purpose model that is conducive for deployment.