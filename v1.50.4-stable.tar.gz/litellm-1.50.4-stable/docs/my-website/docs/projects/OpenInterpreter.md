Open Interpreter lets LLMs run code on your computer to complete tasks.
[Github](https://github.com/KillianLucas/open-interpreter/)