### LiteLLM Proxy
liteLLM Proxy Server: 50+ LLM Models, Error Handling, Caching
[Github](https://github.com/BerriAI/litellm/tree/main/proxy-server)