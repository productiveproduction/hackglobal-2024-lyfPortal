🚀 Evaluate and Evolve.🚀 YiVal is an open source GenAI-Ops framework that allows you to manually or automatically tune and evaluate your AIGC prompts, retrieval configs and fine-tune the model params all at once with your preferred choices of test dataset generation, evaluation algorithms and improvement strategies.

Github: https://github.com/YiVal/YiVal

Docs: https://yival.github.io/YiVal/